<div>Dear <?php echo e($name); ?></div>
<div>Your query has been received. We shall respond to you as soon as possible.</div>
<br><br>
<div>Thanks</div><?php /**PATH E:\Websites_codes\Laravel\searchengine\resources\views/quotemail.blade.php ENDPATH**/ ?>