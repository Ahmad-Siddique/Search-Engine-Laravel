<?php if(session("user")): ?>
    <footer class="bg-<?php echo e(session("user")->color); ?> mt-5">
<?php else: ?>
    <footer class="bg-dark mt-5">
<?php endif; ?>



    <div style="color:white" class="text-center pt-5 pb-5">
        All rights reserved @ 2023
    </div>
  </footer><?php /**PATH E:\Websites_codes\Laravel\searchengine\resources\views/footer.blade.php ENDPATH**/ ?>