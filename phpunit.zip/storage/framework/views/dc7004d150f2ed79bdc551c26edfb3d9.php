<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo $__env->make('bootstraplink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* .container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
} */

        .card {
            width: 500px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #007BFF;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            text-align: left;
            margin-bottom: 5px;
        }

        input {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .switch {
            margin-top: 15px;
            font-size: 14px;
        }

        .switch a {
            color: #007BFF;
            text-decoration: none;
        }
    </style>

</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="">
            <h2 class="mt-4 text-center">Update Resource </h2>
            <form method="POST" action="/postupdateresource/<?php echo e($data['id']); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="id" value=<?php echo e($data['id']); ?> />
                <label for="username">CSI</label>
                <input type="text" class="form-control" value="<?php echo isset($data['CSI']) ? htmlspecialchars($data['CSI']) : ''; ?>" id="username" name="CSI"
                    placeholder="Enter CSI">

                <label for="password">Name</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Name']) ? htmlspecialchars($data['Name']) : ''; ?>" id="password" name="Name"
                    placeholder="Enter your Name">

                <label for="password" class="form-label">Qualification</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Qualification']) ? htmlspecialchars($data['Qualification']) : ''; ?>" id="password"
                    name="Qualification" placeholder="Enter your Qualification">

                <label for="password" class="form-label">Experience</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Experience']) ? htmlspecialchars($data['Experience']) : ''; ?>" id="password" name="Experience"
                    placeholder="Enter your Experience">

                <label for="password" class="form-label">Awards</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Awards']) ? htmlspecialchars($data['Awards']) : ''; ?>" id="password" name="Awards"
                    placeholder="Enter your Awards">


                <label for="password" class="form-label">Currency</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Currency']) ? htmlspecialchars($data['Currency']) : ''; ?>" id="password" name="Currency"
                    placeholder="Enter your Currency">

                <label for="password" class="form-label">Photo</label>
                <input type="file" class="form-control" value="<?php echo isset($data['Photo']) ? htmlspecialchars($data['Photo']) : ''; ?>" id="password" name="Photo"
                    placeholder="Enter your Photo">

                <label for="password" class="form-label">Notes</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Notes']) ? htmlspecialchars($data['Notes']) : ''; ?>" id="password" name="Notes"
                    placeholder="Enter your Notes">

                <label for="password" class="form-label">Engagement_Type</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Engagement']) ? htmlspecialchars($data['Engagement']) : ''; ?>" id="password"
                    name="Engagement_Type" placeholder="Enter your Engagement_Type">

                <label for="password" class="form-label">Availability</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Availability']) ? htmlspecialchars($data['Availability']) : ''; ?>" id="password"
                    name="Availability" placeholder="Enter your Availability">

                <label for="password" class="form-label">Location</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Location']) ? htmlspecialchars($data['Location']) : ''; ?>" id="password" name="Location"
                    placeholder="Enter your Location">

                <label for="password" class="form-label">Nationality</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Nationality']) ? htmlspecialchars($data['Nationality']) : ''; ?>" id="password"
                    name="Nationality" placeholder="Enter your Nationality">

                <label for="password" class="form-label">Age_Years</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Age_Years']) ? htmlspecialchars($data['Age_Years']) : ''; ?>" id="password"
                    name="Age_Years" placeholder="Enter your Age_Years">

                <label for="password" class="form-label">Price Min</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Price_Min']) ? htmlspecialchars($data['Price_Min']) : ''; ?>" id="password"
                    name="Price_Min" placeholder="Enter your Price Min">

                <label for="password" class="form-label">Price Max</label>
                <input type="text" class="form-control" value="<?php echo isset($data['Price_Max']) ? htmlspecialchars($data['Price_Max']) : ''; ?>" id="password"
                    name="Price_Max" placeholder="Enter your Price Max">



                


                <button type="submit">Submit</button>
            </form>

        </div>


    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH E:\Websites_codes\Laravel\searchengine\resources\views/updateresource.blade.php ENDPATH**/ ?>