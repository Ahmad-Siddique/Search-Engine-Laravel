<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('bootstraplink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mt-3 mb-3" style="border:1px">
        <form class="mb-3" action="/searching" method="POST">
            <?php echo csrf_field(); ?>


            <?php if(empty($data)): ?>
                <div class="row">
                    <div class="col-5">
                        <input type="text" name="search" class="form-control" id="exampleFormControlInput1"
                            placeholder="Search anything you like">
                    </div>

                    <div class="col-2">
                        <select name="category" class="form-select" aria-label="Default select example">
                            <option value="Price">Price</option>
                            <option value="Origin">Origin</option>

                            <option value="Availability">Availability</option>
                        </select>
                    </div>

                    <div class="col-2">
                        <select name="sorting" class="form-select" aria-label="Default select example">

                            <option value="Ascending">Ascending</option>
                            <option value="Descending">Descending</option>

                        </select>
                    </div>


                    <div class="col-2">
                        <select name="currency" class="form-select" aria-label="Default select example">
                            <option value="pakistani rupees">pakistani rupees</option>
                            <option value="dollar">dollar</option>

                            <option value="riyal">riyal</option>
                        </select>
                    </div>

                    <div class="col-1">
                        <button type="submit" class="btn btn-md btn-primary">Search</button>
                    </div>






                    <br>


                </div>
            <?php else: ?>
                <div class="row">

                    <div class="col-5">


                        <input type="text" name="search" value="<?php echo e($data); ?>" class="form-control"
                            id="exampleFormControlInput1" placeholder="Search anything you like" />
                    </div>
                    <div class="col-2">
                        <select name="category" class="form-select" aria-label="Default select example">

                            <option value="Origin" <?php if($category == 'Origin'): ?> ? selected : null <?php endif; ?>>Origin
                            </option>
                            <option value="Price" <?php if($category == 'Price'): ?> ? selected : null <?php endif; ?>>Price
                            </option>
                            <option value="Availability" <?php if($category == 'Availability'): ?> ? selected : null <?php endif; ?>>
                                Availability</option>
                        </select>
                    </div>

                    <div class="col-2">
                        <select name="sorting" class="form-select" aria-label="Default select example">

                            <option value="Ascending" <?php if($sorting == 'Ascending'): ?> ? selected : null <?php endif; ?>>
                                Ascending</option>
                            <option value="Descending" <?php if($sorting == 'Descending'): ?> ? selected : null <?php endif; ?>>
                                Descending</option>

                        </select>
                    </div>

                    <div class="col-2">
                        <select name="currency" class="form-select" aria-label="Default select example">
                            <option value="pakistani rupees" <?php if($currency == 'pakistani rupees'): ?> ? selected : null <?php endif; ?>>
                                pakistani rupees</option>
                            <option value="dollar" <?php if($currency == 'dollar'): ?> ? selected : null <?php endif; ?>>dollar
                            </option>

                            <option value="riyal" <?php if($currency == 'riyal'): ?> ? selected : null <?php endif; ?>>riyal
                            </option>

                        </select>
                    </div>


                    <div class="col-1">
                        <button type="submit" class="btn btn-md btn-primary">Search</button>

                    </div>
                </div>
            <?php endif; ?>

        </form>





        

        <div style="display: flex;">
            <?php if(isset($data)): ?>
                <form action="/searching" method="POST" style="margin-right: 10px; display: flex; align-items: center;">

                    <?php echo csrf_field(); ?>


                    <input hidden type="text" name="search" value="<?php echo e($data); ?>" class="form-control"
                        id="exampleFormControlInput1" placeholder="Search anything you like" />

                    <select hidden name="category" class="form-select" aria-label="Default select example">

                        <option value="Origin" <?php if($category == 'Origin'): ?> ? selected : null <?php endif; ?>>
                            Origin
                        </option>
                        <option value="Price" <?php if($category == 'Price'): ?> ? selected : null <?php endif; ?>>
                            Price
                        </option>
                        <option value="Availability" <?php if($category == 'Availability'): ?> ? selected : null <?php endif; ?>>
                            Availability</option>
                    </select>



                    <select hidden name="sorting" class="form-select" aria-label="Default select example">

                        <option value="Ascending" <?php if($sorting == 'Ascending'): ?> ? selected : null <?php endif; ?>>
                            Ascending</option>
                        <option value="Descending" <?php if($sorting == 'Descending'): ?> ? selected : null <?php endif; ?>>
                            Descending</option>

                    </select>



                    <select hidden name="currency" class="form-select" aria-label="Default select example">
                        <option value="pakistani rupees" <?php if($currency == 'pakistani rupees'): ?> ? selected : null <?php endif; ?>>
                            pakistani rupees</option>
                        <option value="dollar" <?php if($currency == 'dollar'): ?> ? selected : null <?php endif; ?>>
                            dollar
                        </option>

                        <option value="riyal" <?php if($currency == 'riyal'): ?> ? selected : null <?php endif; ?>>
                            riyal
                        </option>

                    </select>








                    <button type="submit" style="border:none; " class="btn btn-lg btn-outline-dark">All</button>

                </form>


                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/materials/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Materials</a>
                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/resources/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Resources</a>
                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/services/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Services</a>
                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/equipments/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Equipments</a>
                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/resources/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Gallery</a>
                <a style="border:none;text-decoration:none" class="btn btn-lg btn-outline-dark"
                    href="/resources/<?php echo e($data); ?>/<?php echo e($category); ?>/<?php echo e($sorting); ?>/<?php echo e($currency); ?>">Documents</a>
            <?php endif; ?>
        </div>

        <div class="">
            <?php if(isset($data)): ?>
                <h1><?php echo e($data); ?></h1>
            <?php endif; ?>
            <div class="row">

                <div class="col-9">
                    <?php if(isset($imagedata)): ?>
                        <?php if(count($imagedata) != 0): ?>
                            <h3 class="mb-3">Images</h3>
                            <div class="row">
                                <?php $__currentLoopData = $imagedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-3 mx-1 mt-5">
                                        <img width="200" height="200" src=<?php echo e($item); ?> alt="image" />
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        
                    <?php endif; ?>


                    <?php if(isset($resource)): ?>
                        <?php if(!$resource->isEmpty()): ?>
                            <h3 class="mb-3">Resources</h3>
                            <?php $__currentLoopData = $resource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mb-2 mt-2">

                                            <div><?php echo e($item->Name); ?></div>
                                            <div>CSI Code | <?php echo e($item->CSI); ?></div>
                                            <div><?php echo e($item->Qualification); ?></div>
                                            <div>Price Min |
                                                <?php echo e(number_format(fdiv($item->Price_Min, $currency_rate[0]->price))); ?></div>
                                            <?php if(session('user')): ?>
                                                <?php if(session('user')->role == 'admin' || session('user')->role == 'datamanager' || session('user')->role == 'subscriber'): ?>
                                                    <div>Price Max |
                                                        <?php echo e(number_format(fdiv($item->Price_Max, $currency_rate[0]->price))); ?>

                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>



                                            <div class="collapse" id="gte<?php echo e($item->id); ?>">
                                                <div>
                                                    <div>Currency | <?php echo e($item->Currency); ?></div>
                                                    <div>Location | <?php echo e($item->Location); ?></div>
                                                    <div>Availability | <?php echo e($item->Availability); ?></div>
                                                </div>
                                                
                                            </div>


                                            <a class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#qouteModel" aria-current="page" href="/login">Get a
                                                Quote</a>
                                            <a class="btn btn-primary" data-bs-toggle="collapse"
                                                data-bs-target="#gte<?php echo e($item->id); ?>" role="button"
                                                aria-expanded="false" aria-controls="collapse">
                                                Read More/Less
                                            </a>
                                            <div>
                                                <hr>
                                            </div>






                                            <div class="modal fade" id="qouteModel" tabindex="-1"
                                                aria-labelledby="qouteModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="qouteModalLabel">Get a Quote
                                                            </h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form method="POST" action="/getquote">
                                                                <?php echo csrf_field(); ?>
                                                                <?php if(session('user')): ?>
                                                                    <div class="mb-3">
                                                                        <label for="exampleInputEmail1"
                                                                            class="form-label">Email address</label>
                                                                        <input type="email" name="email"
                                                                            value=<?php echo e(session('user')->email); ?> readonly
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            aria-describedby="emailHelp">

                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="mb-3">
                                                                        <label for="exampleInputEmail1"
                                                                            class="form-label">Email address</label>
                                                                        <input type="email" name="email"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            aria-describedby="emailHelp">

                                                                    </div>
                                                                <?php endif; ?>


                                                                <input type="hidden" placeholder="id" name="table_id"
                                                                    value="<?php echo e($item->id); ?>">
                                                                <input type="hidden" placeholder="id" name="table_name"
                                                                    value="resources">



                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Name</label>
                                                                    <input type="text" name="Name"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>


                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Organization</label>
                                                                    <input type="text" name="Organization"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>


                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Phone number</label>
                                                                    <input type="text" name="Phone_Number"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>


                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Item Description</label>
                                                                    <input type="text" name="Item_Description"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>


                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Quantity</label>
                                                                    <input type="text" name="Quantity"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>

                                                                <div class="mb-3">
                                                                    <label for="exampleInputEmail1"
                                                                        class="form-label">Notes</label>
                                                                    <input type="text" name="Notes"
                                                                        class="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp">

                                                                </div>







                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Save
                                                                        changes</button>
                                                                </div>


                                                        </div>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>



                                        </div>

                                    </div>

                                    <div class="col-3">
                                        <?php
                                        // Check if $item->Photo exists, is not empty, and is not just a "-"
                                        if (isset($item->Photo) && !empty($item->Photo) && $item->Photo !== '-' && $item->Photo !== 'Photo') {
                                            echo $item->Photo;
                                            // Determine if $item->Photo is a URL
                                            if (filter_var($item->Photo, FILTER_VALIDATE_URL)) {
                                                // $item->Photo is a URL, display the image
                                                echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                                echo "<img src='" . htmlspecialchars($item->Photo) . "' alt='cement pic' width='100%' />";
                                                echo '</a>';
                                            } else {
                                                // $item->Photo is a file path, adjust the path as needed and display the image
                                                $basePath = '/path/to/images/';
                                                $imagePath = $basePath . $item->Photo;
                                                echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                                echo "<img src='" . htmlspecialchars($imagePath) . "' alt='cement pic' width='100%' />";
                                                echo '</a>';
                                            }
                                        } else {
                                            // $item->Photo does not exist, is empty, or is "-", optional: display a placeholder or nothing
                                            echo 'No image available.';
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    <?php endif; ?>

                    <?php if(isset($services)): ?>
                        <?php if(!$services->isEmpty()): ?>
                            <h3 class="mb-3">Services</h3>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mb-2 mt-2">

                                            <div><?php echo e($item->Description); ?></div>
                                            <div>CSI Code | <?php echo e($item->CSI); ?></div>
                                            <div>Unit | <?php echo e($item->Unit); ?></div>
                                            <div><?php echo e($item->Specifications); ?></div>
                                            <div>Location | <?php echo e($item->Location); ?></div>
                                            <div>Currency | <?php echo e($item->Currency); ?></div>


                                            <div class="collapse" id="gte<?php echo e($item->id); ?>">

                                                <div>Price Min
                                                    <strong><?php echo e(number_format(fdiv($item->Price_Min, $currency_rate[0]->price))); ?></strong>
                                                    |
                                                </div>
                                                <?php if(session('user')): ?>
                                                    <?php if(session('user')->role == 'admin' || session('user')->role == 'datamanager' || session('user')->role == 'subscriber'): ?>
                                                        <div>Price Max |
                                                            <?php echo e(number_format(fdiv($item->Price_Max, $currency_rate[0]->price))); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>


                                            <div>Monthly Price <a href="">Trend</a>
                                                <strong><?php echo e($item->Monthly_Trend); ?></strong>
                                            </div>

                                        </div>

                                        <a class="btn btn-primary" data-bs-toggle="collapse"
                                            data-bs-target="#gte<?php echo e($item->id); ?>" role="button"
                                            aria-expanded="false" aria-controls="collapse">
                                            Read More/Less
                                        </a>


                                        <div>
                                            <hr>
                                        </div>

                                    </div>

                                </div>

                                <div class="col-3">
                                    <?php
                                    // Check if $item->Photo exists, is not empty, and is not just a "-"
                                    if (isset($item->Photo) && !empty($item->Photo) && $item->Photo !== '-' && $item->Photo !== 'Photo') {
                                        echo $item->Photo;
                                        // Determine if $item->Photo is a URL
                                        if (filter_var($item->Photo, FILTER_VALIDATE_URL)) {
                                            // $item->Photo is a URL, display the image
                                            echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                            echo "<img src='" . htmlspecialchars($item->Photo) . "' alt='cement pic' width='100%' />";
                                            echo '</a>';
                                        } else {
                                            // $item->Photo is a file path, adjust the path as needed and display the image
                                            $basePath = '/path/to/images/';
                                            $imagePath = $basePath . $item->Photo;
                                            echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                            echo "<img src='" . htmlspecialchars($imagePath) . "' alt='cement pic' width='100%' />";
                                            echo '</a>';
                                        }
                                    } else {
                                        // $item->Photo does not exist, is empty, or is "-", optional: display a placeholder or nothing
                                        echo 'No image available.';
                                    }
                                    ?>
                                </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                <?php endif; ?>





                <?php if(isset($equipments)): ?>
                        <?php if(!$equipments->isEmpty()): ?>
                            <h3 class="mb-3">Equipments</h3>
                            <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mb-2 mt-2">

                                            <div><?php echo e($item->Description); ?></div>
                                            <div>CSI Code | <?php echo e($item->CSI); ?></div>
                                            <div>Unit | <?php echo e($item->Unit); ?></div>
                                            <div><?php echo e($item->Specifications); ?></div>
                                            <div>Location | <?php echo e($item->Location); ?></div>
                                            <div>Currency | <?php echo e($item->Currency); ?></div>


                                            <div class="collapse" id="gte<?php echo e($item->id); ?>">

                                                <div>Price Min
                                                    <strong><?php echo e(number_format(fdiv($item->Price_Min, $currency_rate[0]->price))); ?></strong>
                                                    |
                                                </div>
                                                <?php if(session('user')): ?>
                                                    <?php if(session('user')->role == 'admin' || session('user')->role == 'datamanager' || session('user')->role == 'subscriber'): ?>
                                                        <div>Price Max |
                                                            <?php echo e(number_format(fdiv($item->Price_Max, $currency_rate[0]->price))); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>


                                            <div>Monthly Price <a href="">Trend</a>
                                                <strong><?php echo e($item->Monthly_Trend); ?></strong>
                                            </div>

                                        </div>

                                        <a class="btn btn-primary" data-bs-toggle="collapse"
                                            data-bs-target="#gte<?php echo e($item->id); ?>" role="button"
                                            aria-expanded="false" aria-controls="collapse">
                                            Read More/Less
                                        </a>


                                        <div>
                                            <hr>
                                        </div>

                                    </div>

                                </div>

                                <div class="col-3">
                                    <?php
                                    // Check if $item->Photo exists, is not empty, and is not just a "-"
                                    if (isset($item->Photo) && !empty($item->Photo) && $item->Photo !== '-' && $item->Photo !== 'Photo') {
                                        echo $item->Photo;
                                        // Determine if $item->Photo is a URL
                                        if (filter_var($item->Photo, FILTER_VALIDATE_URL)) {
                                            // $item->Photo is a URL, display the image
                                            echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                            echo "<img src='" . htmlspecialchars($item->Photo) . "' alt='cement pic' width='100%' />";
                                            echo '</a>';
                                        } else {
                                            // $item->Photo is a file path, adjust the path as needed and display the image
                                            $basePath = '/path/to/images/';
                                            $imagePath = $basePath . $item->Photo;
                                            echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                            echo "<img src='" . htmlspecialchars($imagePath) . "' alt='cement pic' width='100%' />";
                                            echo '</a>';
                                        }
                                    } else {
                                        // $item->Photo does not exist, is empty, or is "-", optional: display a placeholder or nothing
                                        echo 'No image available.';
                                    }
                                    ?>
                                </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                <?php endif; ?>


                <?php if(isset($materials)): ?>
                    <?php if(!$materials->isEmpty()): ?>
                        <h3 class="mb-3">Materials</h3>
                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-8">
                                    <div class="mb-2 mt-2">

                                        <div><?php echo e($item->Description); ?></div>
                                        <div>CSI Code | <?php echo e($item->CSI); ?></div>
                                        <div><?php echo e($item->Qualification); ?></div>
                                        <div>Origin | <?php echo e($item->Origin); ?></div>
                                        <div>Currency | <?php echo e($item->Currency); ?></div>
                                        <div>Monthly Trend | <?php echo e($item->Monthly_Trend); ?></div>
                                        <div class="collapse" id="gte<?php echo e($item->id); ?>">
                                            <div>Price Min
                                                <strong><?php echo e(number_format(fdiv($item->Price_Min, $currency_rate[0]->price))); ?></strong>
                                                |
                                            </div>
                                            <?php if(session('user')): ?>
                                                <?php if(session('user')->role == 'admin' || session('user')->role == 'datamanager' || session('user')->role == 'subscriber'): ?>
                                                    <div>Price Max |
                                                        <?php echo e(number_format(fdiv($item->Price_Max, $currency_rate[0]->price))); ?>

                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        <div>Availability <strong><?php echo e($item->Availability); ?></strong> </div>

                                        <div>Monthly Price <a href="">Trend</a>
                                            <strong><?php echo e($item->Monthly_Trend); ?></strong>
                                        </div>
                                    </div>

                                    <a class="btn btn-primary" data-bs-toggle="collapse"
                                        data-bs-target="#gte<?php echo e($item->id); ?>" role="button" aria-expanded="false"
                                        aria-controls="collapse">
                                        Read More/Less
                                    </a>
                                    <div>
                                        <hr>
                                    </div>

                                </div>

                            </div>

                            <div class="col-3">
                                <?php
                                // Check if $item->Photo exists, is not empty, and is not just a "-"
                                if (isset($item->Photo) && !empty($item->Photo) && $item->Photo !== '-' && $item->Photo !== 'Photo') {
                                    echo $item->Photo;
                                    // Determine if $item->Photo is a URL
                                    if (filter_var($item->Photo, FILTER_VALIDATE_URL)) {
                                        // $item->Photo is a URL, display the image
                                        echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                        echo "<img src='" . htmlspecialchars($item->Photo) . "' alt='cement pic' width='100%' />";
                                        echo '</a>';
                                    } else {
                                        // $item->Photo is a file path, adjust the path as needed and display the image
                                        $basePath = '/path/to/images/';
                                        $imagePath = $basePath . $item->Photo;
                                        echo "<a href='/images/{{ \$data }}/{{ \$category }}/{{ \$sorting }}'>";
                                        echo "<img src='" . htmlspecialchars($imagePath) . "' alt='cement pic' width='100%' />";
                                        echo '</a>';
                                    }
                                } else {
                                    // $item->Photo does not exist, is empty, or is "-", optional: display a placeholder or nothing
                                    echo 'No image available.';
                                }
                                ?>
                            </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            <?php endif; ?>

            <?php if(@isset($materials)): ?>
                <?php if(@isset($resource)): ?>
                    <?php if(@isset($services)): ?>
                        <?php if(@isset($equipments)): ?>
                        <div>Total Records found
                            <?php echo e(sizeof($materials) + sizeof($resource) + sizeof($services) +sizeof($equipments)); ?></div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>


            <?php if(@isset($materials) && @empty($resource) && @empty($services) && @empty($equipments)): ?>
                <div>Total Records found <?php echo e(sizeof($materials)); ?></div>
            <?php endif; ?>

            <?php if(@isset($resource) && @empty($materials) && @empty($services) && @empty($equipments)): ?>
                <div>Total Records found <?php echo e(sizeof($resource)); ?></div>
            <?php endif; ?>

            <?php if(@isset($services) && @empty($materials) && @empty($resource) && @empty($equipments)): ?>
                <div>Total Records found <?php echo e(sizeof($services)); ?></div>
            <?php endif; ?>
            <?php if(@isset($equipments) && @empty($materials) && @empty($resource) && @empty($services)): ?>
                <div>Total Records found <?php echo e(sizeof($equipments)); ?></div>
            <?php endif; ?>
        </div>

        

        <div class="col-3">
            

        </div>
    </div>

    </div>


    </div>



    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH E:\Websites_codes\Laravel\searchengine\resources\views/contentshow.blade.php ENDPATH**/ ?>