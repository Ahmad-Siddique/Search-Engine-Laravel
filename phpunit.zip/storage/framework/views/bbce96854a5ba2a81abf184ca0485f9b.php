<div>Dear <?php echo e($name); ?></div>
<div><?php echo e($answer); ?></div>
<br>
<div>Thanks</div><?php /**PATH E:\Websites_codes\Laravel\searchengine\resources\views/QuoteResponse.blade.php ENDPATH**/ ?>