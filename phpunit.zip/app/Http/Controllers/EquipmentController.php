<?php

namespace App\Http\Controllers;

use App\Imports\EquipmentsImport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Equipment;
use Maatwebsite\Excel\Facades\Excel;


class EquipmentController extends Controller

{

    function FetchEquipments($search, $category, $sorting, $currency)
    {


        if ($currency) {


            $currencyrate = $currency;
        }


        $currency_rate = DB::table("currency_conversion")->where("currency", $currencyrate)->get();
        // $response = Http::post("http://127.0.0.1:7000/searchingdata", [
        //     "search" => $search
        // ]);
        // $keywords = $response->json();

        $data = trim($search);
        $keywords = explode("+", $data);
        $keys = array_keys($keywords);

        $services = DB::table("equipments_csv");

        for ($x = 0; $x < count($keys); $x++) {

            $services = $services->orWhere("Description", "like",   $keywords[$keys[$x]] . "%")->orWhere("Description", "like",  "% " . $keywords[$keys[$x]] . "%")
                ->orWhere("CSI", "like", $keywords[$keys[$x]] . "%")->orWhere("CSI", "like", "% " . $keywords[$keys[$x]] . "%")
                ->orWhere("Specifications", "like", $keywords[$keys[$x]] . "%")->orWhere("Specifications", "like", "% " . $keywords[$keys[$x]] . "%");
        }


        if ($category == "Price") {
            if ($sorting == "Ascending" || $sorting == "None") {


                $services = $services->orderBy('Price_Min', 'asc');
            } else {


                $services = $services->orderBy('Price_Max', 'desc');
            }
        } else if ($category == "Origin") {
            if ($sorting == "Ascending" || $sorting == "None") {


                $services = $services->orderBy('Location', 'asc');
            } else {


                $services = $services->orderBy('Location', 'desc');
            }
        }


        $services = $services->paginate(3);
        // return $resource;
        return view("contentshow", ["data" => $search, "equipments" => $services, "category" => $category, "sorting" => $sorting, "currency" => $currency, "currency_rate" => $currency_rate]);
    }


    function allequipment()
    {
        $data = DB::table("equipments_csv")->orderBy('created_at', 'desc')->paginate(10);

        return view("allequipment", ["collection" => $data]);
    }


    function addequipmentfile(Request $req)
    {

        Excel::import(new EquipmentsImport, $req->file('file'));

        // $material->save();

        return redirect("/addservicefile");
    }

    function addequipment(Request $req)
    {
        $service = new Equipment;

        $service->CSI = $req->CSI;
        $service->Description = $req->Description;
        $service->Specifications = $req->Specifications;
        $service->Unit = $req->Unit;
        $service->Price_Min = $req->Price_Min;
        $service->Price_Max = $req->Price_Max;
        $service->Currency = $req->Currency;


        $service->Discount = $req->Discount;
        $service->Monthly_Trend = $req->Monthly_Trend;
        $service->Location = $req->Location;
        $service->Notes = $req->Notes;


        // $service->Created_On = $req->Created_On;
        // $service->Update_On = $req->Update_On;
        $service->Keywords = $req->Keywords;

        if ($req->file("Photo")) {
            $service->Photo = $req->file("Photo")->store('img');
        }


        $service->save();
        return redirect("/addequipment");
    }


    function searchequipment(Request $req)
    {
        $search = $req->search;
        // echo $search;
        $data = DB::table("equipments_csv")->orWhere("Description", "like",   $search . "%")->orWhere("Description", "like",  "% " . $search . "%")
        ->orWhere("CSI", "like", $search . "%")->orWhere("CSI", "like", "% " . $search . "%")
        ->orWhere("Specifications", "like", $search . "%")->orWhere("Specifications", "like", "% " . $search . "%")
        ->orderBy('created_at', 'desc')->get();

        // echo $data;
        return view("allequipment", ["collection" => $data]);
        // $material  = Material::
    }

    function updateequipment($id)
    {
        $material = Equipment::find($id);
        return view("updateequipment", ["data" => $material]);
    }


    function postupdateequipment(Request $req)
    {
        $service = Equipment::find($req->id);
        $service->CSI = $req->CSI;
        $service->Description = $req->Description;
        $service->Specifications = $req->Specifications;
        $service->Unit = $req->Unit;
        $service->Price_Min = $req->Price_Min;
        $service->Price_Max = $req->Price_Max;
        $service->Currency = $req->Currency;


        $service->Discount = $req->Discount;
        $service->Monthly_Trend = $req->Monthly_Trend;
        $service->Location = $req->Location;
        $service->Notes = $req->Notes;


        // $service->Created_On = $req->Created_On;
        // $service->Update_On = $req->Update_On;
        $service->Keywords = $req->Keywords;

        if ($req->file("Photo")) {
            $service->Photo = $req->file("Photo")->store('img');
        }


        $service->save();


        return redirect("/updateequipment/" . $req->id);
    }

    function deleteequipment($id)
    {
        $data = Equipment::find($id);
        $data->delete();
        return redirect("allservice");
    }
}
