<div>Dear {{$name}}</div>
<div>{{$answer}}</div>
<br>
<div>Thanks</div>