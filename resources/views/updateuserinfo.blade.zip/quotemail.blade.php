<div>Dear {{$name}}</div>
<div>Your query has been received. We shall respond to you as soon as possible.</div>
<br>
<div>Thanks</div>