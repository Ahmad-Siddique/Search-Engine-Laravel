<!DOCTYPE html>
<html>
<head>
    <title>Quotation Response</title>
</head>
<body>
    <h1>Quotation Response</h1>
    <p>Dear {{ $name }},</p>
    <p>Here is the response to your question:</p>
    <p><strong>Question:</strong> {{ $question }}</p>
    <p><strong>Answer:</strong> {{ $answer }}</p>
    <p>Thank you for reaching out!</p>
</body>
</html>
